export interface IImage {
    id:string;
    fileName:string;
    target:string;
    
}