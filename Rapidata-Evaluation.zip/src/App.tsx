import React from 'react';
import './App.css';
import RouteList from './routes/RouteList';

function App() {
  return (
    <div className="App">
        <RouteList />
    </div>
  );
}

export default App;
