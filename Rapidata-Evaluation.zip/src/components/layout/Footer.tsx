import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
        <div className='footer-text'>
            Privacy Policy
            © 2023 Rapidata. All rights reserved.
        </div>
    </div>
  )
}

export default Footer